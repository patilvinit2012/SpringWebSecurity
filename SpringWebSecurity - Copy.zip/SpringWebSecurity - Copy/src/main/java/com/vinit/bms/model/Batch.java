package com.vinit.bms.model;

import lombok.Data;

@Data
public class Batch {

	private int batchId;
	private String batchName;
}
