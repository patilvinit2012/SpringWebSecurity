package com.vinit.bms;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vinit.bms.model.Batch;

@RestController
@RequestMapping("api")
public class BatchController {

	List<Batch> batches = new ArrayList<>();

	public BatchController() {
		Batch b1 = new Batch();
		Batch b2 = new Batch();

		b1.setBatchId(1);
		b1.setBatchName("B-01");

		b2.setBatchId(2);
		b2.setBatchName("B-02");

		batches.add(b1);
		batches.add(b2);

	}

	@GetMapping("batch")
	public List<Batch> getBatches() {
		return batches;
	}
}
